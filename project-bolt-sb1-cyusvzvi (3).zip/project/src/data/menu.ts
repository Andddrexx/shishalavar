import { MenuCategory } from '../types';

export const menuData: MenuCategory[] = [
  {
    id: 'refrescos',
    title: 'Refrescos',
    icon: 'beer',
    items: [
      { name: 'RED BULL', price: '2,50 €' },
      { name: 'RED BULL SIN AZÚCAR', price: '2,50 €' },
      { name: 'COCA COLA (Light, Zero)', price: '2,50 €' },
      { name: 'FANTA (Light, Zero)', price: '2,50 €' },
      { name: 'TÓNICA SCHWEPPES (Zero)', price: '2,50 €' },
      { name: 'SEVEN UP', price: '2,00 €' },
      { name: 'LIPTON TEA', price: '2,30 €' },
      { name: 'CASERA', price: '1,30 €' },
      { name: 'PEPSI', price: '2,00 €' }
    ]
  },
  {
    id: 'cervezas',
    title: 'Cervezas',
    icon: 'beer',
    items: [
      { name: 'ÁMBAR TOSTADA', price: '2,90 €' },
      { name: 'MAHOU CINCO ESTRELLAS', price: '2,90 €' },
      { name: 'ESTRELLA GALICIA', price: '2,90 €' },
      { name: 'ALHAMBRA', price: '2,90 €' },
      { name: 'CORONITA', price: '2,90 €' },
      { name: 'CERVEZA 1870', price: '2,90 €' }
    ]
  },
  {
    id: 'combinados',
    title: 'Combinados',
    icon: 'wine',
    items: [
      {
        name: 'BRUGAL',
        price: '8,00 €',
        description: 'Ron'
      },
      {
        name: 'BRUGAL EXTRA VIEJO',
        price: '8,00 €',
        description: 'Ron'
      },
      {
        name: 'BARCELO',
        price: '8,00 €',
        description: 'Ron'
      },
      {
        name: 'LEGENDARIO',
        price: '8,00 €',
        description: 'Ron'
      },
      {
        name: 'JB',
        price: '7,00 €',
        description: 'Whisky'
      },
      {
        name: 'RED LABEL',
        price: '7,00 €',
        description: 'Whisky'
      },
      {
        name: 'DYC',
        price: '7,00 €',
        description: 'Whisky'
      },
      {
        name: 'BALLANTINES',
        price: '7,00 €',
        description: 'Whisky'
      },
      {
        name: 'JAMESON',
        price: '8,00 €',
        description: 'Whisky'
      },
      {
        name: 'ERISTOFF',
        price: '7,00 €',
        description: 'Vodka'
      },
      {
        name: 'BELVEDERE',
        price: '8,00 €',
        description: 'Vodka'
      },
      {
        name: 'ABSOLUT',
        price: '7,00 €',
        description: 'Vodka'
      },
      {
        name: 'LARIOS 12',
        price: '9,00 €',
        description: 'Ginebra'
      },
      {
        name: 'PUERTO DE INDIAS',
        price: '8,00 €',
        description: 'Ginebra'
      },
      {
        name: 'BOMBAY SAPPHIRE',
        price: '9,00 €',
        description: 'Ginebra'
      },
      {
        name: 'NORDÉS',
        price: '9,00 €',
        description: 'Ginebra'
      },
      {
        name: 'FEATER',
        price: '6,00 €',
        description: 'Ginebra'
      }
    ]
  },
  {
    id: 'cocteles',
    title: 'Cócteles',
    icon: 'cocktail',
    items: [
      {
        name: 'MOJITO CLÁSICO',
        price: '9,00 €',
        ingredients: ['Ron', 'Soda', 'Limón', 'Menta']
      },
      {
        name: 'SEX ON THE BEACH',
        price: '8,00 €',
        ingredients: ['Vodka', 'Zumo de naranja', 'Zumo de arándanos', 'Zumo de melocotón']
      },
      {
        name: 'LONG ISLAND ICE TEA',
        price: '8,00 €',
        ingredients: ['Gin', 'Vodka', 'Ron', 'Tequila', 'Triple seco', 'Zumo de limón']
      },
      {
        name: 'PIÑA COLADA',
        price: '8,00 €',
        ingredients: ['Ron', 'Zumo de piña', 'Leche de coco']
      },
      {
        name: 'CAIPIROSKA',
        price: '6,00 €',
        ingredients: ['Vodka', 'Zumo de limón', 'Azúcar']
      },
      {
        name: 'BLOODY MARY',
        price: '8,00 €',
        ingredients: ['Vodka', 'Zumo de tomate', 'Salsa inglesa', 'Tabasco', 'Lima']
      }
    ]
  },
  {
    id: 'sin-alcohol',
    title: 'Cócteles sin alcohol y Zumos',
    icon: 'glass-water',
    items: [
      {
        name: 'PIÑA COLADA SIN ALCOHOL',
        price: '7,00 €',
        ingredients: ['Zumo de piña', 'Zumo de coco', 'Sirope de coco']
      },
      {
        name: 'SAN FRANCISCO',
        price: '7,00 €',
        ingredients: ['Zumo de piña', 'Zumo de naranja', 'Zumo de limón', 'Mix de frutas']
      },
      {
        name: 'LIMONADA',
        price: '4,00 €',
        ingredients: ['Limón', 'Azúcar']
      },
      { name: 'ZUMO DE PIÑA', price: '2,50 €' },
      { name: 'ZUMO DE ZANAHORIA', price: '3,00 €' },
      { name: 'ZUMO DE NARANJA', price: '3,00 €' },
      { name: 'ZUMO DE TOMATE', price: '3,50 €' },
      { name: 'ZUMO DE MELOCOTÓN', price: '2,50 €' }
    ]
  },
  {
    id: 'cachimbas',
    title: 'Cachimbas',
    icon: 'cloud',
    items: [
      {
        name: 'BERLIN NIGHTS',
        price: '14,00 €',
        description: 'Melocotón y menta'
      },
      {
        name: 'BLUE YELLOW',
        price: '14,00 €',
        description: 'Melón y arándanos'
      },
      {
        name: 'GREEN LEON KIZZ',
        price: '14,00 €',
        description: 'Lima y menta'
      },
      {
        name: 'LADY KILLER',
        price: '14,00 €',
        description: 'Melocotón, mango, menta y hielo'
      },
      {
        name: 'LOVE 66',
        price: '14,00 €',
        description: '6 sabores y menta'
      },
      {
        name: 'DOS MANZANAS',
        price: '14,00 €'
      },
      {
        name: 'THREE ANGELS',
        price: '14,00 €',
        description: 'Pomelo, maracuyá y hielo'
      },
      {
        name: 'ESKIMO LEON',
        price: '14,00 €',
        description: 'Kiwi, limón y hielo'
      },
      {
        name: 'GIPSY KINGS',
        price: '14,00 €',
        description: 'Melón dulce, melocotón, sandía y limón'
      },
      {
        name: 'BLUE DRAGON',
        price: '14,00 €',
        description: 'Fruta dragón, arándanos y bombón helado'
      },
      {
        name: 'SKYFALL',
        price: '14,00 €',
        description: 'Melocotón, sandía, melón y hielo'
      },
      {
        name: 'HAWAI',
        price: '14,00 €',
        description: 'Piña, mango y menta'
      },
      {
        name: 'AMORE',
        price: '14,00 €',
        description: 'Piña, crema de plátano y hielo'
      },
      {
        name: 'LAVANDA SHISHA',
        price: '14,95 €'
      }
    ]
  },
  {
    id: 'comida',
    title: 'Comida',
    icon: 'utensils',
    items: [
      {
        name: 'HAMBURGUESA DE CERDO',
        price: '1,00 €',
        ingredients: ['Cerdo', 'Lechuga', 'Tomate', 'Queso']
      },
      {
        name: 'HAMBURGUESA DE TERNERA',
        price: '1,00 €',
        ingredients: ['Ternera', 'Lechuga', 'Tomate', 'Queso']
      },
      {
        name: 'HAMBURGUESA DE POLLO',
        price: '1,00 €',
        ingredients: ['Pollo', 'Lechuga', 'Tomate', 'Queso']
      }
    ]
  }
];