import React from 'react';
import { ChevronDown } from 'lucide-react';
import * as Icons from 'lucide-react';
import { MenuCategory } from '../types';

interface MenuSectionProps {
  category: MenuCategory;
  isOpen: boolean;
  onToggle: () => void;
}

export const MenuSection: React.FC<MenuSectionProps> = ({
  category,
  isOpen,
  onToggle,
}) => {
  const IconComponent = Icons[category.icon as keyof typeof Icons];

  return (
    <div className="mb-6">
      <button
        onClick={onToggle}
        className={`w-full flex items-center justify-between p-4 rounded-lg transition-all duration-300 ${
          isOpen 
            ? 'bg-lavender-600 text-white shadow-lg' 
            : 'bg-lavender-100 hover:bg-lavender-200 text-neutral-850'
        }`}
      >
        <div className="flex items-center gap-3">
          {IconComponent && (
            <IconComponent 
              size={24} 
              className={isOpen ? 'text-lavender-100' : 'text-lavender-600'}
            />
          )}
          <span className="font-montserrat font-semibold">{category.title}</span>
        </div>
        <ChevronDown
          size={20}
          className={`transition-transform duration-300 ${
            isOpen ? 'rotate-180 text-lavender-100' : 'text-lavender-600'
          }`}
        />
      </button>
      
      <div
        className={`grid gap-4 transition-all duration-300 overflow-hidden ${
          isOpen ? 'max-h-[2000px] opacity-100 mt-4' : 'max-h-0 opacity-0'
        }`}
      >
        {category.items.map((item, index) => (
          <div
            key={index}
            className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-lavender-100"
          >
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h3 className="font-montserrat font-medium text-neutral-850">
                  {item.name}
                </h3>
                {item.description && (
                  <p className="text-sm text-neutral-600 mt-1">{item.description}</p>
                )}
                {item.ingredients && (
                  <p className="text-sm text-lavender-600 mt-1">
                    {item.ingredients.join(' • ')}
                  </p>
                )}
              </div>
              <span className="font-montserrat font-semibold text-neutral-850 ml-4">
                {item.price}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}