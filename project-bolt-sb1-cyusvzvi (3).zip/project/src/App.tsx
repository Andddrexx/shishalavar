import React, { useState } from 'react';
import { Cloud } from 'lucide-react';
import { MenuSection } from './components/MenuSection';
import { menuData } from './data/menu';

function App() {
  const [openCategory, setOpenCategory] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-neutral-950 text-white">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-lavender-900 to-lavender-700 py-16">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex items-center justify-center gap-4 mb-6">
            <Cloud size={48} className="text-lavender-200" />
            <h1 className="font-montserrat text-4xl md:text-5xl font-bold">
              Lavanda Shisha Lounge
            </h1>
          </div>
          <p className="text-center text-lavender-200 font-light max-w-2xl mx-auto">
            Disfruta de nuestra selección de bebidas premium y cachimbas en un ambiente único
          </p>
        </div>
      </header>

      {/* Menu Section */}
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <h2 className="font-montserrat text-3xl font-bold text-center mb-12 text-lavender-400">
          Nuestra Carta
        </h2>
        
        <div className="space-y-6">
          {menuData.map((category) => (
            <MenuSection
              key={category.id}
              category={category}
              isOpen={openCategory === category.id}
              onToggle={() =>
                setOpenCategory(openCategory === category.id ? null : category.id)
              }
            />
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-neutral-850 text-lavender-200 py-8 mt-16">
        <div className="container mx-auto px-4 text-center">
          <p className="font-montserrat mb-2">Lavanda Shisha Lounge</p>
          <p className="text-sm text-lavender-400">
            Abierto todos los días de 18:00 - 02:00 • Reservas: +34 614 234 758
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;