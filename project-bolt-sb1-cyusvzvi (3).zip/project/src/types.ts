export interface MenuItem {
  name: string;
  price: string;
  description?: string;
  ingredients?: string[];
}

export interface MenuCategory {
  id: string;
  title: string;
  icon: string;
  items: MenuItem[];
}